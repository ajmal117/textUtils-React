import './App.css';
import About from './components/About';
import Navbar from './components/Navbar';
import TextForm from './components/TextForm';
import Alert from './components/Alert';
import React, { useState } from 'react';
// import { Router } from 'react-router-dom';

import {
  BrowserRouter as Router,
  Route,
  Routes
} from "react-router-dom";

function App() {
  const [mode, setMode] = useState('light'); //whether dark mode is enable or not
  const [alert, setAlert] = useState(null);
  // const [rosemode, setroseMode] = useState('light');

  const showAlert = (message, type) => {
    setAlert({
      msg: message,
      type: type
    })
    setTimeout(() => {
      setAlert(null);
    }, 4000);
  }

  const toggleMode = () => {
    if (mode === 'light') {
      setMode('dark');
      document.body.style.backgroundColor = "rgb(38 39 52)";
      showAlert("Dark mode has been unable", "success")
      document.title = "Texttiles - Dark mode enable"

      // // To pass any message (like virus Notification)  
      // setInterval(() => {
      //   document.title = "TextUtils is amazing"
      // }, 2000);


      // setInterval(() => {
      //   document.title = "install TextUtils is now"
      // }, 3000);
    }
    else {
      setMode('light');
      document.body.style.backgroundColor = "white";
      showAlert("light mode has been unable", "success")
      document.title = "Texttiles - Light mode enable"

    }
  }

  // const toggleMode2 =()=>{
  //   if(rosemode === 'light'){  
  //     setroseMode ('dark');
  //     document.body.style.backgroundColor = "red";
  //     showAlert("Dark mode has been unable", "success")
  //   }
  //   else{
  //     setroseMode ('light');
  //     document.body.style.backgroundColor = "orange" ;
  //     showAlert("light mode has been unable", "success")
  //   }
  // }

  return (

    <>

      <Router>

        {/* <Navbar title="TextUtils" aboutText ="AboutTextUtils"/> */}
        {/* <Navbar/> */}
        <Navbar title="TextUtils" mode={mode} toggleMode={toggleMode} />
        <Alert alert={alert} />
        <div className="container my-3">
          {/* <About /> */}
        <Routes>
            <Route path="/about" element= { <About />}>
             
            </Route>
            <Route path="/" element={ <TextForm showAlert={showAlert} heading="Enter the text to analyse below" mode={mode} />}>
             
            </Route>
            </Routes>
          {/* <About/> */}
        </div>

      </Router>
    </>
  );
}

export default App;
